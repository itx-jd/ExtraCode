import java.util.*;

// This code if or Shortest Path when don't need to return back

public class Dijkstra {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the total number of vertices: ");
        int totalVertices = scanner.nextInt();

        System.out.print("Enter the total number of edges: ");
        int totalEdges = scanner.nextInt();

        Graph graph = new Graph();

        for (int i = 1; i <= totalVertices; i++) {
            graph.addNode(new Node(String.valueOf(i)));
        }

        for (int i = 0; i < totalEdges; i++) {
            System.out.println("Enter edge details " + (i + 1) + ":");
            System.out.print("Source vertex: ");
            int sourceVertex = scanner.nextInt();
            System.out.print("Destination vertex: ");
            int destinationVertex = scanner.nextInt();
            System.out.print("Weight: ");
            int weight = scanner.nextInt();

            Node sourceNode = graph.getNode(String.valueOf(sourceVertex));
            Node destinationNode = graph.getNode(String.valueOf(destinationVertex));

            if (sourceNode != null && destinationNode != null) {
                sourceNode.addDestination(destinationNode, weight);
            } else {
                System.out.println("Invalid vertex. Please enter valid vertices.");
                i--; // Decrement i to re-enter edge details
            }
        }

        System.out.print("Enter the source vertex: ");
        int sourceVertex = scanner.nextInt();
        System.out.print("Enter the destination vertex: ");
        int destinationVertex = scanner.nextInt();

        Node sourceNode = graph.getNode(String.valueOf(sourceVertex));
        Node destinationNode = graph.getNode(String.valueOf(destinationVertex));

        if (sourceNode != null && destinationNode != null) {
            graph = calculateShortestPathFromSource(graph, sourceNode);
            System.out.println("Shortest path from " + sourceNode.getName() + " to " + destinationNode.getName() + ":");
            System.out.println(destinationNode.getShortestPath());
            System.out.println("Total distance: " + destinationNode.getDistance());
        } else {
            System.out.println("Invalid vertices. Please enter valid vertices.");
        }

        scanner.close();
    }

    private static Graph calculateShortestPathFromSource(Graph graph, Node source) {
        source.setDistance(0);

        Set<Node> settledNodes = new HashSet<>();
        Set<Node> unsettledNodes = new HashSet<>();

        unsettledNodes.add(source);

        while (!unsettledNodes.isEmpty()) {
            Node currentNode = getLowestDistanceNode(unsettledNodes);
            unsettledNodes.remove(currentNode);
            for (Map.Entry<Node, Integer> adjacencyPair : currentNode.getAdjacentNodes().entrySet()) {
                Node adjacentNode = adjacencyPair.getKey();
                Integer edgeWeight = adjacencyPair.getValue();
                if (!settledNodes.contains(adjacentNode)) {
                    calculateMinimumDistance(adjacentNode, edgeWeight, currentNode);
                    unsettledNodes.add(adjacentNode);
                }
            }
            settledNodes.add(currentNode);
        }
        return graph;
    }

    private static Node getLowestDistanceNode(Set<Node> unsettledNodes) {
        Node lowestDistanceNode = null;
        int lowestDistance = Integer.MAX_VALUE;
        for (Node node : unsettledNodes) {
            int nodeDistance = node.getDistance();
            if (nodeDistance < lowestDistance) {
                lowestDistance = nodeDistance;
                lowestDistanceNode = node;
            }
        }
        return lowestDistanceNode;
    }

    private static void calculateMinimumDistance(Node evaluationNode, Integer edgeWeight, Node sourceNode) {
        Integer sourceDistance = sourceNode.getDistance();
        if (sourceDistance + edgeWeight < evaluationNode.getDistance()) {
            evaluationNode.setDistance(sourceDistance + edgeWeight);
            LinkedList<Node> shortestPath = new LinkedList<>(sourceNode.getShortestPath());
            shortestPath.add(sourceNode);
            evaluationNode.setShortestPath(shortestPath);
        }
    }

    private static class Graph {

        private Set<Node> nodes = new HashSet<>();

        public void addNode(Node node) {
            nodes.add(node);
        }

        public Node getNode(String nodeName) {
            for (Node node : nodes) {
                if (node.getName().equals(nodeName)) {
                    return node;
                }
            }
            return null;
        }
    }

    private static class Node {

        private String name;

        private List<Node> shortestPath = new LinkedList<>();

        private Integer distance = Integer.MAX_VALUE;

        Map<Node, Integer> adjacentNodes = new HashMap<>();

        public void addDestination(Node destination, int distance) {
            adjacentNodes.put(destination, distance);
        }

        public Node(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public Integer getDistance() {
            return distance;
        }

        public void setDistance(Integer distance) {
            this.distance = distance;
        }

        public List<Node> getShortestPath() {
            return shortestPath;
        }

        public void setShortestPath(List<Node> shortestPath) {
            this.shortestPath = shortestPath;
        }

        public Map<Node, Integer> getAdjacentNodes() {
            return adjacentNodes;
        }
        
        @Override
        public String toString() {
            return name;
        }
    }
}
