import java.util.*;


class Pair<K, V> {
    private final K key;
    private final V value;


    public Pair(K key, V value) {
        this.key = key;
        this.value = value;
    }


    public K getKey() {
        return key;
    }


    public V getValue() {
        return value;
    }
}


class Node {
    Vector<Pair<Integer, Integer>> path;
    double[][] reducedMatrix;
    double cost;
    int vertex;
    int level;
}


public class BackToPathSalesman {
    static final int N = 5;
    static final double INF = Double.MAX_VALUE;


    static Node newNode(double[][] parentMatrix, Vector<Pair<Integer, Integer>> path, int level, int i, int j) {
        Node node = new Node();
        node.path = new Vector<>(path);


        if (level != 0) {
            node.path.add(new Pair<>(i, j));
        }


        node.reducedMatrix = new double[N][N];
        for (int x = 0; x < N; x++) {
            System.arraycopy(parentMatrix[x], 0, node.reducedMatrix[x], 0, N);
        }


        for (int k = 0; level != 0 && k < N; k++) {
            node.reducedMatrix[i][k] = INF;
            node.reducedMatrix[k][j] = INF;
        }


        node.reducedMatrix[j][0] = INF;


        node.level = level;
        node.vertex = j;


        return node;
    }


    static double rowReduction(double[][] reducedMatrix, double[] row) {
        Arrays.fill(row, INF);


        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (reducedMatrix[i][j] < row[i]) {
                    row[i] = reducedMatrix[i][j];
                }
            }
        }


        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (reducedMatrix[i][j] != INF && row[i] != INF) {
                    reducedMatrix[i][j] -= row[i];
                }
            }
        }


        return 0;
    }


    static double columnReduction(double[][] reducedMatrix, double[] col) {
        Arrays.fill(col, INF);


        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (reducedMatrix[i][j] < col[j]) {
                    col[j] = reducedMatrix[i][j];
                }
            }
        }


        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (reducedMatrix[i][j] != INF && col[j] != INF) {
                    reducedMatrix[i][j] -= col[j];
                }
            }
        }


        return 0;
    }


    static double calculateCost(double[][] reducedMatrix) {
        double cost = 0;


        double[] row = new double[N];
        rowReduction(reducedMatrix, row);


        double[] col = new double[N];
        columnReduction(reducedMatrix, col);


        for (int i = 0; i < N; i++) {
            cost += (row[i] != INF) ? row[i] : 0;
            cost += (col[i] != INF) ? col[i] : 0;
        }


        return cost;
    }


    static void TSPPAthPrint(Vector<Pair<Integer, Integer>> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.println((list.get(i).getKey() + 1) + " -> " + (list.get(i).getValue() + 1));
        }
    }


    static class MinHeapComparator implements Comparator<Node> {
        public int compare(Node lhs, Node rhs) {
            return Double.compare(lhs.cost, rhs.cost);
        }
    }


    static double solve(double[][] CostGraphMatrix, int sourceVertex) {
        PriorityQueue<Node> pq = new PriorityQueue<>(new MinHeapComparator());
        Vector<Pair<Integer, Integer>> v = new Vector<>();


        Node root = newNode(CostGraphMatrix, v, 0, -1, sourceVertex);
        root.cost = calculateCost(root.reducedMatrix);
        pq.add(root);


        while (!pq.isEmpty()) {
            Node min = pq.poll();
            int i = min.vertex;


            if (min.level == N - 1) {
                min.path.add(new Pair<>(i, sourceVertex));
                TSPPAthPrint(min.path);
                return min.cost;
            }


            for (int j = 0; j < N; j++) {
                if (min.reducedMatrix[i][j] != INF) {
                    Node child = newNode(min.reducedMatrix, min.path, min.level + 1, i, j);
                    child.cost = min.cost + min.reducedMatrix[i][j] + calculateCost(child.reducedMatrix);
                    pq.add(child);
                }
            }


            min = null;
        }


        return 0;
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        double[][] CostGraphMatrix = new double[N][N];
        System.out.println("Enter the cost matrix (separated by space):");
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                CostGraphMatrix[i][j] = scanner.nextDouble();
            }
        }


        System.out.print("Enter the source vertex: ");
        int sourceVertex = scanner.nextInt();


        System.out.println("Total cost is " + solve(CostGraphMatrix, sourceVertex));


        scanner.close();
    }
}