import java.util.Arrays;

public class LeastCostTransportation {

    public static void main(String[] args) {
    	int[] supply = {20,70,25,30};  
        int[] demand = {65,30,50};  

        int[][] costMatrix = {
            {5,1,7},
            {7,4,6},
            {3,2,5},
            {0,0,0}
  
//    	int[] supply = {75, 125, 100};  
//        int[] demand = {80, 65, 70, 85};  
//
//        int[][] costMatrix = {
//            {464, 513, 654, 867},
//            {352, 416, 690, 791},
//            {995, 682, 388, 685}
        };

        int[][] result = solveTransportationProblem(supply, demand, costMatrix);

        // Print the result step by step
        printStepByStep(result, costMatrix);
    }

    public static int[][] solveTransportationProblem(int[] supply, int[] demand, int[][] costMatrix) {
        int numSources = supply.length;
        int numDestinations = demand.length;

        int[][] result = new int[numSources][numDestinations];

        int[] remainingSupply = Arrays.copyOf(supply, numSources);
        int[] remainingDemand = Arrays.copyOf(demand, numDestinations);

        // Iterate until all supply and demand are satisfied
        while (Arrays.stream(remainingSupply).sum() > 0 && Arrays.stream(remainingDemand).sum() > 0) {
            // Find the indices of the minimum cost cell
            int[] minCostCell = findMinimumCostCell(costMatrix, remainingSupply, remainingDemand);

            int i = minCostCell[0];
            int j = minCostCell[1];

            // Determine the quantity to transport based on the minimum of remaining supply and demand
            int quantity = Math.min(remainingSupply[i], remainingDemand[j]);

            // Update the result matrix with the calculated quantity
            result[i][j] = quantity;

            // Update the remaining supply and demand
            remainingSupply[i] -= quantity;
            remainingDemand[j] -= quantity;
        }

        return result;
    }

    // Function to find the indices of the minimum cost cell
    private static int[] findMinimumCostCell(int[][] costMatrix, int[] remainingSupply, int[] remainingDemand) {
        int minCost = Integer.MAX_VALUE;
        int[] minCostCell = {-1, -1};

        for (int i = 0; i < costMatrix.length; i++) {
            for (int j = 0; j < costMatrix[i].length; j++) {
                if (remainingSupply[i] > 0 && remainingDemand[j] > 0 && costMatrix[i][j] < minCost) {
                    minCost = costMatrix[i][j];
                    minCostCell[0] = i;
                    minCostCell[1] = j;
                }
            }
        }

        return minCostCell;
    }

    // Function to print step by step and calculate total cost
    public static void printStepByStep(int[][] result, int[][] costMatrix) {
        int totalCost = 0;
        System.out.println("Step by Step Result:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[i].length; j++) {
                int quantity = result[i][j];
                if (quantity > 0) {
                    System.out.println("Transport " + quantity + " units from Source " + (i + 1) +
                            " to Destination " + (j + 1) + " with cost " + costMatrix[i][j]);
                    totalCost += quantity * costMatrix[i][j];
                }
            }
        }
        System.out.println("Total Cost: " + totalCost);
    }
}
