import java.util.*;
 
public class Hungerian {
	public static int n;
	public static int costing[][];
	public static int maxingmatching;
	public static int leftx[], lefty[];
	public static int xy[];
	public static int yx[];
	public static boolean setS[], setT[];
    public static int slack[];
	public static int slackxvertex[];
	public static int previous[];
 
	public static void entry_lable() {
        Arrays.fill(leftx, 0);
        Arrays.fill(lefty, 0);
        for (int x = 0; x < n; x++)
            for (int y = 0; y < n; y++)
            	leftx[x] = Math.max(leftx[x], costing[x][y]);
	}
	public static int assignmentProblem(int Arr[], int N) {
        n = N;
        costing = new int[n][n];
        leftx = new int[n];
        lefty = new int[n];
        setS = new boolean[n];
        setT = new boolean[n];
        slack = new int[n];
        slackxvertex = new int[n];
        previous = new int[n];
 
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                costing[i][j] = -1 * Arr[i * n + j];
 
        int ans = -1 * assigmentproblem();
 
        return ans;
	}
 
 
 
	public static void addvalue(int x, int previousx) {
       
        setS[x] = true;
        previous[x] = previousx;
        for (int y = 0; y < n; y++)
            if (leftx[x] + lefty[y] - costing[x][y] < slack[y]) {
            	slack[y] = leftx[x] + lefty[y] - costing[x][y];
            	slackxvertex[y] = x;
            }
	}
	public static void printMatrix(int[][] matrix) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
            	System.out.print(matrix[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
	}
	public static void aug() {
        if (maxingmatching == n) return;
        int x, y;
        int q[] = new int[n], wr = 0, rd = 0;
        Arrays.fill(setS, false);
        Arrays.fill(setT, false);
        Arrays.fill(previous, -1);
        int root = -1;
 
        for (x = 0; x < n; x++) {
            if (xy[x] == -1) {
            	q[wr++] = root = x;
            	previous[x] = -2;
            	setS[x] = true;
            	break;
            }
        }
        if (root == -1) {
            return;
        }
        for (y = 0; y < n; y++) {
            slack[y] = leftx[root] + lefty[y] - costing[root][y];
            slackxvertex[y] = root;
        }
 
        while (true) {
            while (rd < wr) {
            	x = q[rd++];
            	for (y = 0; y < n; y++)
                	if (costing[x][y] == leftx[x] + lefty[y] && !setT[y]) {
                    	if (yx[y] == -1) break;
                    	setT[y] = true;
                    	q[wr++] = yx[y];
 	                   addvalue(yx[y], x);
                	}
            	if (y < n)
                	break;
            }
            if (y < n)
            	break;
 
            updatingvalues();
 
            wr = rd = 0;
            for (y = 0; y < n; y++)
            	if (!setT[y] && slack[y] == 0) {
                	if (yx[y] == -1) {
                    	x = slackxvertex[y];
                    	break;
                	} else {
                    	setT[y] = true;
                        if (!setS[yx[y]]) {
                        	q[wr++] = yx[y];
                        	addvalue(yx[y], slackxvertex[y]);
                    	}
                	}
            	}
            if (y < n) break;
        }
 
        if (y < n) {
            maxingmatching++;
            for (int cx = x, cy = y, ty; cx != -2; cx = previous[cx], cy = ty) {
            	ty = xy[cx];
            	yx[cy] = cx;
            	xy[cx] = cy;
            }
            aug();
        }
	}
	public static void updatingvalues() {
        int x, y;
        int delta = 99999999;
        for (y = 0; y < n; y++)
            if (!setT[y])
            	delta = Math.min(delta, slack[y]);
        for (x = 0; x < n; x++)
            if (setS[x])
            	leftx[x] -= delta;
        for (y = 0; y < n; y++)
            if (setT[y])
            	lefty[y] += delta;
        for (y = 0; y < n; y++)
            if (!setT[y])
            	slack[y] -= delta;
	}
 
	public static int assigmentproblem() {
        int ret = 0;
        maxingmatching = 0;
        xy = new int[n];
        yx = new int[n];
        Arrays.fill(xy, -1);
        Arrays.fill(yx, -1);
        entry_lable();
        aug();
 
        for (int x = 0; x < n; x++)
            ret += costing[x][xy[x]];
 
        return ret;
	}
 
  
  
 
   public static void main(String[] args) {
	int n = 4;
	int Arr[] = {13,13,6,1000,
				4,10,1000,5,
				7,2,8,9,
				1000,7,8,6};
    Hungerian ob = new Hungerian();
   // System.out.println("Original Cost Matrix:");
	//ob.printMatrix(costing);
    System.out.println("Optimal Solution:");
 
	int result = ob.assignmentProblem(Arr, n);
    System.out.println("Total Cost: " + result);
    System.out.println("Optimal Assignment:");
 
    for (int i = 0; i < n; i++) {
        System.out.println("Worker " + (char)('a' + i) + " is assigned to Job " + (xy[i] + 1) + " (Cost: " + Arr[i * n + xy[i]] + ")");
	}
}
}