import java.util.Arrays;
import java.util.Scanner;

public class TravellingSalesman {

    static int[][] tspGraph;
    static int[][] resGraph;
    static int[] visited;
    static int n, cost;

    public static void travellingSalesman(int currentVertex) {
        int k, adjacentVertex = 999;
        int min = 999;
        visited[currentVertex] = 1;
        System.out.print((currentVertex + 1) + " ");

        for (k = 0; k < n; k++) {
            if ((tspGraph[currentVertex][k] != 0) && (visited[k] == 0)) {
                if (tspGraph[currentVertex][k] < min) {
                    min = tspGraph[currentVertex][k];
                }
                adjacentVertex = k;
            }
        }

        if (min != 999) {
            cost = cost + min;
        }

        if (adjacentVertex == 999) {
            adjacentVertex = 0;
            System.out.print((adjacentVertex + 1));
            cost = cost + tspGraph[currentVertex][adjacentVertex];
            return;
        }

        travellingSalesman(adjacentVertex);
    }

    public static void main(String[] args) {
    	
    	
    	
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the total number of vertices: ");
        n = scanner.nextInt();

        tspGraph = new int[n][n];
        visited = new int[n];
        Arrays.fill(visited, 0);

        System.out.println("Enter the adjacency matrix (enter 0 for no edge):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tspGraph[i][j] = scanner.nextInt();
            }
        }
        
        resGraph = new int[n][n];
        
        resGraph[0][2] = 1;
    	resGraph[1][0] = 1;
    	resGraph[1][2] = 1;
    	resGraph[2][3] = 1;
        
      
        System.out.print("Enter the starting vertex: ");
        int startingVertex = scanner.nextInt();
        
        System.out.println("\n\n adjacency matrix (enter 0 for no edge):");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
            	System.out.print(tspGraph[i][j]+"\t");
            }
            System.out.println();
        }


        if (startingVertex >= 1 && startingVertex <= n) {
            System.out.print("\nShortest Path: ");
            travellingSalesman(startingVertex - 1);
            System.out.println("\nMinimum Cost: " + cost);
        } else {
            System.out.println("Invalid starting vertex. Please enter a valid vertex.");
        }

        scanner.close();
    }
}
