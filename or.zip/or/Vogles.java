import java.util.Arrays;
import java.util.Scanner;

public class Vogles {
	
	// Aiman code

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of rows in the transportation matrix: ");
        int n = scanner.nextInt();
        System.out.println("Enter the number of columns in the transportation matrix: ");
        int m = scanner.nextInt();

        double[][] grid = new double[n][m];
        for (int i = 0; i < n; i++) {
            System.out.println("Enter elements for row " + (i + 1) + ":");
            for (int j = 0; j < m; j++) {
                grid[i][j] = scanner.nextDouble();
            }
        }

        System.out.println("Enter the supply values (separated by spaces): ");
        double[] supply = new double[n];
        for (int i = 0; i < n; i++) {
            supply[i] = scanner.nextDouble();
        }

        System.out.println("Enter the demand values (separated by spaces): ");
        double[] demand = new double[m];
        for (int j = 0; j < m; j++) {
            demand[j] = scanner.nextDouble();
        }

        Vogles vogels = new Vogles();
        vogels.solveTransportationProblem(grid, supply, demand);

        scanner.close(); // Remember to close the Scanner object
    }

    public void solveTransportationProblem(double[][] grid, double[] supply, double[] demand) {
        int n = grid.length;
        int m = grid[0].length;
        double ans = 0;
        double INF = 1000.0;

        while (Arrays.stream(supply).sum() != 0 || Arrays.stream(demand).sum() != 0) {
            double[] rowDiff = new double[n];
            double[] colDiff = new double[m];

            for (int i = 0; i < n; i++) {
                double[] rowValues = Arrays.copyOf(grid[i], m);
                Arrays.sort(rowValues);
                rowDiff[i] = rowValues[1] - rowValues[0];
            }

            for (int j = 0; j < m; j++) {
                double[] colValues = new double[n];
                for (int i = 0; i < n; i++) {
                    colValues[i] = grid[i][j];
                }
                Arrays.sort(colValues);
                colDiff[j] = colValues[1] - colValues[0];
            }

            double maxi1 = Arrays.stream(rowDiff).max().getAsDouble();
            double maxi2 = Arrays.stream(colDiff).max().getAsDouble();

            if (maxi1 >= maxi2) {
                for (int ind = 0; ind < n; ind++) {
                    if (rowDiff[ind] == maxi1) {
                        double mini1 = Arrays.stream(grid[ind]).min().getAsDouble();
                        for (int ind2 = 0; ind2 < m; ind2++) {
                            if (grid[ind][ind2] == mini1) {
                                double mini2 = Math.min(supply[ind], demand[ind2]);
                                ans += mini2 * mini1;
                                supply[ind] -= mini2;
                                demand[ind2] -= mini2;

                                System.out.println("Allocate " + mini2 + " to cell (" + ind + ", " + ind2 + ") with cost " + mini1);

                                if (demand[ind2] == 0) {
                                    for (int r = 0; r < n; r++) {
                                        grid[r][ind2] = INF;
                                    }
                                } else {
                                    Arrays.fill(grid[ind], INF);
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
            } else {
                for (int ind = 0; ind < m; ind++) {
                    if (colDiff[ind] == maxi2) {
                        double mini1 = INF;
                        for (int j = 0; j < n; j++) {
                            mini1 = Math.min(mini1, grid[j][ind]);
                        }

                        for (int ind2 = 0; ind2 < n; ind2++) {
                            if (grid[ind2][ind] == mini1) {
                                double mini2 = Math.min(supply[ind2], demand[ind]);
                                ans += mini2 * mini1;
                                supply[ind2] -= mini2;
                                demand[ind] -= mini2;

                                System.out.println("Allocate " + mini2 + " to cell (" + ind2 + ", " + ind + ") with cost " + mini1);

                                if (demand[ind] == 0) {
                                    for (int r = 0; r < n; r++) {
                                        grid[r][ind] = INF;
                                    }
                                } else {
                                    Arrays.fill(grid[ind2], INF);
                                }
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        }

        System.out.println("The final feasible solution is " + ans);
    }
}