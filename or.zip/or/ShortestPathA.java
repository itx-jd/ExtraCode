import java.util.*;

class Edge2 {
	int src, dest;
	float weight;

	Edge2(int src, int dest, float weight) {
		this.src = src;
		this.dest = dest;
		this.weight = weight;
	}
}

class Graph2 {
	int V, E;
	Edge[] edge;

	Graph2(int V, int E) {
		this.V = V;
		this.E = E;
		edge = new Edge[E];
		for (int i = 0; i < E; ++i) {
			edge[i] = new Edge(0, 0, 0);
		}
	}
}

public class ShortestPathA {
	static void printPath(int[] parent, int j) {
		if (parent[j] == -1)
			return;

		printPath(parent, parent[j]);
		System.out.print(" -> " + j);
	}

	static void printArr(float[] dist, int[] parent, int n, int src) {
		System.out.println("Vertex Distance from Source   Path");
		for (int i = 0; i < n; ++i) {
			if (i != src) {
				System.out.print(src + " to " + i + " (");
				if (dist[i] == Float.MAX_VALUE) {
					System.out.print("INF)   " + src);
				} else {
					System.out.print(dist[i] + ")   " + src);
				}
				printPath(parent, i);
				System.out.println();
			}
		}
	}

	static void BellmanFord(Graph graph, int src) {
		int V = graph.V;
		int E = graph.E;
		float[] dist = new float[V];
		int[] parent = new int[V];

		for (int i = 0; i < V; i++) {
			dist[i] = Float.MAX_VALUE;
			parent[i] = -1;
		}

		dist[src] = 0;

		for (int i = 1; i <= V - 1; i++) {
			for (int j = 0; j < E; j++) {
				int u = graph.edge[j].src;
				int v = graph.edge[j].dest;
				float weight = graph.edge[j].weight;

				if (dist[u] != Float.MAX_VALUE && dist[u] + weight < dist[v]) {
					dist[v] = dist[u] + weight;
					parent[v] = u;
				}
			}
		}

		for (int i = 0; i < E; i++) {
			int u = graph.edge[i].src;
			int v = graph.edge[i].dest;
			float weight = graph.edge[i].weight;

			if (dist[u] != Float.MAX_VALUE && dist[u] + weight < dist[v]) {
				System.out.println("Graph contains negative weight cycle");
				return;
			}
		}

		printArr(dist, parent, V, src);
	}

	public static void main(String[] args) {

		int V = 8;

		int E = 15;

		Graph graph = new Graph(V, E);

		int mat[][] = { 
				{ 0, 1, 10 }, 
				{ 0, 2, 3 }, 
				{ 0, 3, 4 }, 
				{ 1, 4, 2 }, 
				{ 1, 5, 5 }, 
				{ 2, 1, 6 }, { 3, 2, 2 },
				{ 2, 5, 5 }, { 3, 5, 5 }, { 3, 6, 8 }, { 4, 7, 5 }, { 5, 4, 5 }, { 5, 6, 2 }, { 5, 7, 8 },
				{ 5, 7, 15 } };

		for (int i = 0; i < E; ++i) {

			graph.edge[i] = new Edge2(mat[i][0], mat[i][1], mat[i][2]);

		}

		System.out.print("Enter the source vertex: ");
		int sourceVertex = 0;

		BellmanFord(graph, sourceVertex);
	}
}