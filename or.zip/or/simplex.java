import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import java.util.Arrays;

public class simplex {
    public static void main(String[] args) {
    BigM1 m = new BigM1();
    m.initialize();
    double[] coffevars = {3, 5};
        double[] tempcoffeArray = Arrays.stream(coffevars).map(coff -> -coff).toArray();
        int sizeOfCoffeArray = coffevars.length;
        int numOfCons = 3;
        double[] Coffbasic = new double[numOfCons];
        double[] SmallbValues = {4, 12, 18};
        double[] rightsidevalues = SmallbValues;
        double calculatedValue = 0;
        double[][] AmetrixValues = new double[numOfCons][sizeOfCoffeArray];

        AmetrixValues[0][0] = 1;
        AmetrixValues[0][1] = 0;
        AmetrixValues[1][0] = 0;
        AmetrixValues[1][1] = 2;
        AmetrixValues[2][0] = 3;
        AmetrixValues[2][1] = 2;

        double[][] nonbasicvalues = AmetrixValues;
        double[][] CapitalBValues = new double[numOfCons][numOfCons];

        for (int i = 0; i < numOfCons; i++) {
            for (int j = 0; j < numOfCons; j++) {
                CapitalBValues[i][j] = (i == j) ? 1 : 0;
            }
        }

        double[][] basicvalues = CapitalBValues;

        while (Arrays.stream(tempcoffeArray).anyMatch(coff -> coff < 0)) {
            int ReplacingIndexFromNonBasic = getmaxCoffIndex(coffevars);
            System.out.println("ReplacingIndexFromNonBasic");
            System.out.println(ReplacingIndexFromNonBasic);
            int ReplacingIndexFromBasic = calratiotest(nonbasicvalues, SmallbValues, ReplacingIndexFromNonBasic);
            System.out.println("ReplacingIndexFromBasic");
            System.out.println(ReplacingIndexFromBasic);
            basicvalues = replaceColumnInBasicValues(basicvalues, nonbasicvalues, ReplacingIndexFromNonBasic, ReplacingIndexFromBasic);
            System.out.println("basicvalues");
            printMatrix(basicvalues);
            double[][] inversebasicvalues = calculateInverse(basicvalues);
            System.out.println("inversebasicvalues");
            printMatrix(inversebasicvalues);
            SmallbValues = Binverseb(inversebasicvalues, rightsidevalues);
            System.out.println("SmallbValues");
            printVector(SmallbValues);
            Coffbasic = calculateCB(Coffbasic, coffevars, ReplacingIndexFromBasic, ReplacingIndexFromNonBasic);
            System.out.println("Coffbasic");
            printVector(Coffbasic);
            calculatedValue = calculateCBinverseBintob(Coffbasic, SmallbValues);
            System.out.println("calculatedValue");
            System.out.println(calculatedValue);
            double[] BinverseAminusC = calCBintoBinverseAminusC(basicvalues, nonbasicvalues, Coffbasic, coffevars);
            tempcoffeArray = Arrays.stream(BinverseAminusC).map(Math::abs).toArray();
            coffevars = tempcoffeArray;
            System.out.println("coffeArray");
            printVector(coffevars);
            System.out.println("tempcoffeArray");
            printVector(tempcoffeArray);
            System.out.println();
        }
    }

    public static int getmaxCoffIndex(double[] coffeArray) {
        double maxCoff = coffeArray[0];
        int maxIndex = 0;

        for (int i = 1; i < coffeArray.length; i++) {
            if (coffeArray[i] > maxCoff) {
                maxCoff = coffeArray[i];
                maxIndex = i;
            }
        }

        return maxIndex;
    }

    public static int calratiotest(double[][] nonbasicvalues, double[] SmallbValues, int ReplacingIndexFromNonBasic) {
        double[] ratios = new double[nonbasicvalues.length];

        for (int i = 0; i < nonbasicvalues.length; i++) {
            if (nonbasicvalues[i][ReplacingIndexFromNonBasic] > 0) {
                ratios[i] = SmallbValues[i] / nonbasicvalues[i][ReplacingIndexFromNonBasic];
            } else {
                ratios[i] = Double.POSITIVE_INFINITY;
            }
        }

        double minRatio = Double.POSITIVE_INFINITY;
        int minIndex = -1;

        for (int i = 0; i < ratios.length; i++) {
            if (ratios[i] < minRatio) {
                minRatio = ratios[i];
                minIndex = i;
            }
        }

        return minIndex;
    }

    public static double[][] replaceColumnInBasicValues(double[][] basicvalues, double[][] nonbasicvalues, int replacingIndexFromNonBasic, int replacingIndexFromBasic) {
        if (nonbasicvalues.length != basicvalues.length) {
            throw new IllegalArgumentException("Both matrices must have the same number of rows for replacement.");
        }

        for (int i = 0; i < basicvalues.length; i++) {
            basicvalues[i][replacingIndexFromBasic] = nonbasicvalues[i][replacingIndexFromNonBasic];
        }

        return basicvalues;
    }

    public static double[][] calculateInverse(double[][] matrix) {
        int n = matrix.length;
        double[][] augmentedMatrix = new double[n][2 * n];

        // Create an augmented matrix [matrix | I]
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 2 * n; j++) {
                if (j < n) {
                    augmentedMatrix[i][j] = matrix[i][j];
                } else {
                    augmentedMatrix[i][j] = (i == j - n) ? 1.0 : 0.0;
                }
            }
        }

        // Perform row operations to get the left side to the identity matrix
        for (int i = 0; i < n; i++) {
            double pivot = augmentedMatrix[i][i];

            // Divide the current row by the pivot
            for (int j = 0; j < 2 * n; j++) {
                augmentedMatrix[i][j] /= pivot;
            }

            // Eliminate other rows
            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = augmentedMatrix[k][i];
                    for (int j = 0; j < 2 * n; j++) {
                        augmentedMatrix[k][j] -= factor * augmentedMatrix[i][j];
                    }
                }
            }
        }

        // Extract the right side (inverse matrix)
        double[][] inverseMatrix = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                inverseMatrix[i][j] = augmentedMatrix[i][j + n];
            }
        }

        return inverseMatrix;
    }


   
   
    public static double[] Binverseb(double[][] inversebasicvalues, double[] rightsidevalues) {
        double[] result = new double[inversebasicvalues.length];

        for (int i = 0; i < inversebasicvalues.length; i++) {
            for (int j = 0; j < inversebasicvalues[0].length; j++) {
                result[i] += inversebasicvalues[i][j] * rightsidevalues[j];
            }
        }

        return result;
    }

    public static double[] calculateCB(double[] Coffbasic, double[] coffeArray, int ReplacingIndexFromBasic, int ReplacingIndexFromNonBasic) {
        Coffbasic[ReplacingIndexFromBasic] = coffeArray[ReplacingIndexFromNonBasic];
        return Coffbasic;
    }

    public static double calculateCBinverseBintob(double[] Coffbasic, double[] SmallbValues) {
        double result = 0;

        for (int i = 0; i < Coffbasic.length; i++) {
            result += Coffbasic[i] * SmallbValues[i];
        }

        return result;
    }

    public static double[] calCBintoBinverseAminusC(double[][] basicvalues, double[][] nonbasicvalues, double[] Coffbasic, double[] coffeArray) {
        double[] result = new double[coffeArray.length];

        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < nonbasicvalues.length; j++) {
                result[i] += Coffbasic[j] * nonbasicvalues[j][i];
            }
            result[i] -= coffeArray[i];
        }

        return result;
    }

    public static void printVector(double[] vector) {
        for (double value : vector) {
            System.out.print(value + " ");
        }
        System.out.println();
    }

    public static void printMatrix(double[][] matrix) {
        for (double[] row : matrix) {
            for (double value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}
 class BigM1{

    static double M = 999999.99;
    static List<Double> C_j = new ArrayList<>();
    static List<Double> Z_j = new ArrayList<>();
    static List<Double> C_B = new ArrayList<>();
    static List<String> B = new ArrayList<>();
    static List<Double> X_B = new ArrayList<>();
    static List<String> vars = new ArrayList<>();
    static List<String> OnEqualVar = new ArrayList<>();
    static List<Double> difference = new ArrayList<>();
    static double[][] table;
    static String[] rowVars;  
    static String[] basicVars;
    static String storeArray;
    static boolean problemType = false;
    static boolean canPrint = true;
    public static void initialize() {

        System.out.println("press 1 for max and 2 for min");
        Scanner input = new Scanner(System.in);
        int type = input.nextInt();
        while (type > 2 || type <= 0) {
            type = input.nextInt();
        }

        problemType = type == 1;

        System.out.println("enter num of var");
        int NumOfVar = input.nextInt();

        System.out.println("enter num of cons");
        int NumOfCons = input.nextInt();

        System.out.println("coefficients of Objective");
        double[] objective_arr = new double[NumOfVar];
        for (int i=0; i<NumOfVar; i++) {
            objective_arr[i] = problemType ? input.nextDouble() : - input.nextDouble();

            String str = "x" + (i+1);
            vars.add(str);

        }

        for (int i=0; i<objective_arr.length; i++) {
             C_j.add(objective_arr[i]);
        }

        List<List<Double>> list = new ArrayList<>();
        int point = NumOfVar;
        int var = 1;
        int art = 1;

        for (int j=0; j<NumOfCons; j++) {
            System.out.println("LHS coefficients of constraints(" + (j+1) + ") : ");
            List<Double> l = new ArrayList<>();
            for (int i=0; i<NumOfVar; i++) {
                double num = input.nextDouble();
                l.add(num);
            }

            System.out.println("Inequality option: \n" + "\t\t 1) ≤ \n" + "\t\t 2) ≥ \n" + "\t\t 3) = ");
            int choice = input.nextInt();
            while (choice > 3 || choice <= 0) {
                choice = input.nextInt();
            }

            System.out.print("RHS coefficient of constraints(" + (j+1) + ") : ");
            double b_val = input.nextDouble();
            X_B.add((double) Math.abs(b_val));

            for (int i=0; i<point; i++) {
                l.add(0.0);
            }

            if(b_val < 0) {

                for (int i=0; i<l.size(); i++) {
                    l.set(i, -l.get(i));
                }

                if(choice == 1) {
                    l.set( point++, -1.0);
                    C_j.add(0.0);

                    l.set(point++, 1.0);
                    C_j.add(-M);

                    String s = "s" + (var++);
                    storeArray += " " + s;
                    vars.add(s);

                    String a = "a" + (art++);
                    storeArray += " " + a;
                    vars.add(a);

                } else if(choice == 2) {
                    l.set(point++, 1.0);
                    C_j.add(0.0);

                    String s = "s" + (var++);
                    storeArray += " " + s;
                    vars.add(s);

                } else {
                    l.set(point++, 1.0);
                    C_j.add(-M);

                    String a = "a" + (art++);
                    storeArray += " " + a;
                    vars.add(a);
                }

            } else {

                if(choice == 1) {
                    l.set(point++, 1.0);
                    C_j.add(0.0);

                    String s = "s" + (var++);
                    storeArray += " " + s;
                    vars.add(s);

                } else if(choice == 2) {
                    l.set(point++, -1.0);
                    C_j.add(0.0);
                    l.set(point++, 1.0);
                    C_j.add(-M);

                    String s = "s" + (var++);
                    storeArray += " " + s;
                    vars.add(s);

                    String a = "a" + (art++);
                    storeArray += " " + a;
                    vars.add(a);

                } else {
                    l.set(point++, 1.0);
                    C_j.add(-M);

                    String a = "a" + (art++);
                    storeArray += " " + a;
                    vars.add(a);
                }
            }

            list.add(l);

        }
        System.out.println();
        table = new double[NumOfCons][list.get(list.size()-1).size()];
        for (int i=0; i<list.size(); i++) {
            for (int j=0; j<list.get(i).size(); j++) {
                table[i][j] = list.get(i).get(j);
            }
        }


//        for(int i=0;i<table.length;i++) {
//        	for(int j=0;j<table.length;j++) {
//        		System.out.print(table[i][j]+"   ");
//        	}
//        	System.out.println("");
//        }
        System.out.println(storeArray);
        System.out.println(C_j);
        System.out.println(Arrays.deepToString(table));  

        for (int i=0; i<table.length; i++) {
            for (int j=NumOfVar; j<C_j.size(); j++) {
                if(table[i][j] == 1.0) {
                    B.add(vars.get(j));
                    C_B.add(C_j.get(j));
                }
            }
        }

        for (int i=0; i<C_j.size(); i++) {
            if(C_j.get(i) == -M) {
                OnEqualVar.add(vars.get(i));
            }
        }
        optimize();

        System.out.println();
        System.out.println(difference);
        System.out.println("Final table: " + Arrays.deepToString(table));

        if(canPrint) {
            printSolution();
        }

    }


    public static boolean ifminExists() {

        diff();

        boolean state = false;

        for (int i=0; i<difference.size(); i++) {
            if (difference.get(i) < 0) {
                state = true;
                break;
            }
        }

        return state;
    }

    public static void rowOperation(int index, int min_index) {

        double num = table[min_index][index];

        X_B.set(min_index, X_B.get(min_index)/num);

        for (int i=0; i<C_j.size(); i++) {
            table[min_index][i] = table[min_index][i] / num;
        }
        for (int i=0; i<table.length; i++) {

            if (i != min_index) {
                double cal = -table[i][index];

                for (int j=0; j<C_j.size(); j++) {
                    table[i][j] = cal*table[min_index][j] + table[i][j];
                }


                X_B.set(i, cal*X_B.get(min_index) + X_B.get(i));

            }
        }


    }


    public static void printSolution() {

        boolean yes = true;

        for (int i=0; i<OnEqualVar.size(); i++) {
            for (int j=0; j<B.size(); j++) {
                if(OnEqualVar.get(i).equals(B.get(j)) && X_B.get(j)>0) {
                    yes = false;
                    break;
                }

            }
        }


        if (!yes) {
            System.out.println("No Solution");

        } else {

            System.out.println("Feasible Solution:");

            for (int i=0; i<vars.size(); i++) {
                boolean state = false;

                for (int j=0; j<B.size(); j++) {
                    if(vars.get(i).equals(B.get(j))) {
                        System.out.println("The value of " + vars.get(i) + " is: " + X_B.get(j));
                        state = true;
                        break;
                    }

                }

                if(!state) {
                    System.out.println("The value of " + vars.get(i) + " is: " + 0);
                }
            }

            float total = 0;
            for (int i=0; i<X_B.size(); i++) {
                total += C_B.get(i)*X_B.get(i);
            }

            if (problemType) {
                System.out.println("The value of Z_max" + total);
            } else {
                System.out.println("The value of Z_min" + -total);
            }

        }



    }


    public static void diff() {

        for (int i=0; i<C_j.size(); i++) {
            double val = 0;
            for (int j=0; j<table.length; j++) {
                val += C_B.get(j)*table[j][i];
            }

            Z_j.add(val);
            difference.add(Z_j.get(i) - C_j.get(i));
        }

    }


    public static void fillVars(int n, int m) {

        basicVars = new String[m+1];
        basicVars[0] = "c";

        for (int i=0; i<m; i++) {
            basicVars[i+1] = "s" + (i+1);
        }

        rowVars = new String[n+m+2];
        rowVars[0] = "z";
        for (int i=0; i<n; i++) {
            rowVars[i+1] = "x" + (i+1);
        }

        for (int i=0; i<m; i++) {
            rowVars[n+i+1] = "s" + (i+1);
        }

        rowVars[n+m+1] = "b";

    }

    public static int minIndex() {

        int index = 0;
        double min = Double.MAX_VALUE;

        for (int i=0; i<difference.size(); i++) {
            if (difference.get(i) < min) {
                index = i;
                min = difference.get(i);
            }
        }

        return index;
    }

    public static void optimize() {

        int iter = 1;

        while (ifminExists() && iter < 1500) {

            int index = minIndex();

            double min_ratio = Double.MAX_VALUE;
            int min_index = 0;

            boolean state = false;

            for (int j=0; j<table.length; j++) {

                if (table[j][index] > 0) {
                    state = true;
                    double ratio = X_B.get(j) / table[j][index];

                    if(ratio < min_ratio) {
                        min_ratio = ratio;
                        min_index = j;
                    }
                }
            }

            if(!state) {
                System.out.println("unbounded solution");
                canPrint = false;
                break;

            } else {

                System.out.println("Iteration - " + iter);
                System.out.println(difference);
                System.out.println(Arrays.deepToString(table));
                System.out.println("Incoming Variable" + vars.get(index));
                System.out.println("Outgoing Variable" + B.get(min_index));
                System.out.println();

                B.set(min_index, vars.get(index));
                C_B.set(min_index, C_j.get(index));

                rowOperation(index, min_index);
                iter++;

            }

            Z_j = new ArrayList<>();
            difference = new ArrayList<>();

        }
    }


}