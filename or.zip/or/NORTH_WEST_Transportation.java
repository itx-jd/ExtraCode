import java.util.Arrays;

public class NORTH_WEST_Transportation {

    public static void main(String[] args) {
    	int[] supply = {20,70,25,30};  
        int[] demand = {65,30,50};  

        int[][] costMatrix = {
            {5,1,7},
            {7,4,6},
            {3,2,5},
            {0,0,0}
        };

        int[][] result = solveTransportationProblem(supply, demand, costMatrix);

        // Print the result step by step
        printStepByStep(result, costMatrix);
    }

    public static int[][] solveTransportationProblem(int[] supply, int[] demand, int[][] costMatrix) {
        int numSources = supply.length;
        int numDestinations = demand.length;

        int[][] result = new int[numSources][numDestinations];

        int[] remainingSupply = Arrays.copyOf(supply, numSources);
        int[] remainingDemand = Arrays.copyOf(demand, numDestinations);

        int i = 0, j = 0;

        while (i < numSources && j < numDestinations) {
            int quantity = Math.min(remainingSupply[i], remainingDemand[j]);

            result[i][j] = quantity;
            remainingSupply[i] -= quantity;
            remainingDemand[j] -= quantity;

            if (remainingSupply[i] == 0) {
                i++;
            }

            if (remainingDemand[j] == 0) {
                j++;
            }
        }

        return result;
    }

    public static void printStepByStep(int[][] result, int[][] costMatrix) {
        int totalCost = 0;
        System.out.println("Step by Step Result:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[i].length; j++) {
                int quantity = result[i][j];
                if (quantity > 0) {
                    System.out.println("Transport " + quantity + " units from Source " + (i + 1) +
                            " to Destination " + (j + 1) + " with cost " + costMatrix[i][j]);
                    totalCost += quantity * costMatrix[i][j];
                }
            }
        }
        System.out.println("Total Cost: " + totalCost);
    }
}
