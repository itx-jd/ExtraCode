import java.util.*;

class Edge {
    int src, dest;
    float weight;

    Edge(int src, int dest, float weight) {
        this.src = src;
        this.dest = dest;
        this.weight = weight;
    }
}

class Graph {
    int V, E;
    Edge2[] edge;

    Graph(int V, int E) {
        this.V = V;
        this.E = E;
        edge = new Edge2[E];
        for (int i = 0; i < E; ++i) {
            edge[i] = new Edge2(0, 0, 0);
        }
    }
}

public class ShortestPathCharacter {
    static void printPath(int[] parent, int j) {
        if (parent[j] == -1)
            return;

        printPath(parent, parent[j]);
        System.out.print(" -> " + convertToLetter(j));
    }

    static void printArr(float[] dist, int[] parent, int n, int src) {
        System.out.println("\nVertex Distance from Source Path \n");
        for (int i = 0; i < n; ++i) {
            if (i != src) {
                System.out.print(convertToLetter(src) + " to " + convertToLetter(i) + " (");
                if (dist[i] == Float.MAX_VALUE) {
                    System.out.print("INF)   " + src);
                } else {
                    System.out.print(dist[i] + ")   " + convertToLetter(src));
                }
                printPath(parent, i);
                System.out.println();
            }
        }
    }

    static void BellmanFord(Graph2 graph, int src) {
        int V = graph.V;
        int E = graph.E;
        float[] dist = new float[V];
        int[] parent = new int[V];

        for (int i = 0; i < V; i++) {
            dist[i] = Float.MAX_VALUE;
            parent[i] = -1;
        }

        dist[src] = 0;

        for (int i = 1; i <= V - 1; i++) {
            for (int j = 0; j < E; j++) {
                int u = graph.edge[j].src;
                int v = graph.edge[j].dest;
                float weight = graph.edge[j].weight;

                if (dist[u] != Float.MAX_VALUE && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                }
            }
        }

        for (int i = 0; i < E; i++) {
            int u = graph.edge[i].src;
            int v = graph.edge[i].dest;
            float weight = graph.edge[i].weight;

            if (dist[u] != Float.MAX_VALUE && dist[u] + weight < dist[v]) {
                System.out.println("Graph contains negative weight cycle");
                return;
            }
        }

        printArr(dist, parent, V, src);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter last vertices letter: ");
        char noVertices = scanner.next().charAt(0);
        int V = findIndex(noVertices)+1;

        System.out.print("Enter number of edges: ");
        int E = scanner.nextInt();

        Graph2 graph = new Graph2(V, E);

        System.out.println("Enter source, destination, and weight for each edge:");
        for (int i = 0; i < E; ++i) {
        	
            System.out.println("For Edge " + (i + 1) + ":");
            System.out.print("Enter source (in Character): ");
            char srcInput = scanner.next().charAt(0);
            int src = findIndex(srcInput);

            System.out.print("Enter destination (in Character): ");
            char destInput = scanner.next().charAt(0);
            int dest = findIndex(destInput);

            System.out.print("Enter weight: ");
            float weight = scanner.nextFloat();

            graph.edge[i] = new Edge(src, dest, weight);
        }

        System.out.print("\nEnter the source vertex (in Character): ");
        char sourceVertexInput = scanner.next().charAt(0);
        int sourceVertex = findIndex(sourceVertexInput);

        scanner.close();

        BellmanFord(graph, sourceVertex);
    }
    
    public static int findIndex(char ch) {
        // Convert the character to lowercase to handle both uppercase and lowercase letters
        char lowercaseChar = Character.toLowerCase(ch);

        // Check if the character is a valid English letter
        if (lowercaseChar < 'a' || lowercaseChar > 'z') {
            System.out.println("Invalid input: Please enter a valid English letter.");
            return -1;  // Return -1 for invalid input
        }

        // Calculate and return the index
        return lowercaseChar - 'a';
    }
    
    public static char convertToLetter(int index) {
        if (index < 0 || index >= 26) {
            System.out.println("Error: Index out of range. Please enter an index between 0 and 25.");
            System.exit(1); // Exit the program with an error code
        }

        return (char) ('A' + index);
    }
    
}